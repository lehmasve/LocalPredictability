#ifndef DISTRIBUTION_H
#define DISTRIBUTION_H
arma::mat rmvnorm_mat(int iN, arma::vec vMu, arma::mat mSigma);
#endif
